height = int(input("Enter the height: "))
width = int(input("Enter the width: "))
depth = int(input("Enter the depth: "))
volume = height * width * depth
print("The volume of the cuboid is:", volume, "cubic units")
