import random, math
smaller = int(input("Enter the smaller number: "))
larger = int(input("Enter the larger number: "))
myNumber = random.randint(smaller, larger)
count = 10
while True:
    
    count += 1
    userNumber = int(input("Enter your guess: "))
    math.log = myNumber
    print("You will need a minimum of ", math.log, "guesses")
    if userNumber < myNumber:
        print("too small:")
    elif userNumber > myNumber:
        print("Too large:")
    else:
        print("Congratulations: You've got it in", count, "tries:")
        break
