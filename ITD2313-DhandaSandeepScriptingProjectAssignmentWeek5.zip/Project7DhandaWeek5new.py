count = 1
rate = 0
rate = int(input("Enter rate: "))
increase = rate * .02
newRate3 = 0
newRate4 = 0

for year in range(1, rate + 1, 10):
    rate = rate + (rate * increase)
    
    print(year, "", rate)
    


