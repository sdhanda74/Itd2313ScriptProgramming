price = int(input("Enter purchase price: "))

interest = .12
rate = interest/12
monthly = .05 * (price - (.10 * price))
month = 0
balance = price


while balance > 0:
    interest = balance * rate
    principal = monthly - interest
    remainingbalance = balance - monthly
    print(month, "", balance, "", interest, "", principal, "",  monthly, "", remainingbalance)

    balance = remainingbalance
    month += 1
           
