Organisms = int(input("Enter the number of organisms: "))
rateOfGrowth = int(input("Enter the rate of growth: "))
NumberOfhours = int(input("Enter number of hours to achieve growth rate: "))

    
total = 0
newOrganism = Organisms * rateOfGrowth
print("The number of organisms for rate of growth of", rateOfGrowth, "is: ",
      newOrganism)
    
for count in range(6):
    newOrganism += newOrganism 
    NumberOfhours = NumberOfhours + 6
    
    print("After", NumberOfhours, "hours", "the total is", newOrganism)




                    
