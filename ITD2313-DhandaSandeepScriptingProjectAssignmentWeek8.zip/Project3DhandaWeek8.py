def isSorted(lst):
    
    if not lst:
        return True

    
    for i in range(len(lst) - 1):
        if lst[i] > lst[i + 1]:
            return False

    return True

print(isSorted([]))               
print(isSorted([1, 2, 3, 4]))     
print(isSorted([1, 3, 2, 4]))     
print(isSorted([4, 3, 4, 4]))     

