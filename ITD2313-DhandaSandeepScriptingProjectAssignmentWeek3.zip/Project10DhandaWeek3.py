import math

wage = input("Enter hourly wage: ")
hours = input("Enter number of hours worked: ")
overtime = input("Enter overtime hours: ")

Overtime = int(overtime) * (1.5 * int(wage))
weeklypay = int(wage) * int(hours) + int(Overtime)
print("The total weekly pay is:$", weeklypay)
