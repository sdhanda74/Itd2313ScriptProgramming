height = 0
totaltwo = 0
intialHeight = int(input("Enter initial height: "))
total = (intialHeight * .6)
totaltwo += total + (intialHeight * .6)
for count in range(1, 2):
    
    totaltwo += (total * 0.6) 
print(totaltwo + intialHeight)

    
    
