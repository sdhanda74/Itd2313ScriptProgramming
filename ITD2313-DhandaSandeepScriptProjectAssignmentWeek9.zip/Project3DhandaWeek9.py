import turtle

def drawFractalLine(t, distance, angle, level):
    if level == 0:
        t.forward(distance)
    else:
        distance /= 3.0
        drawFractalLine(t, distance, angle, level - 1)
        t.left(60)
        drawFractalLine(t, distance, angle, level - 1)
        t.right(120)
        drawFractalLine(t, distance, angle, level - 1)
        t.left(60)
        drawFractalLine(t, distance, angle, level - 1)


t = turtle.Turtle()


initial_distance = 200
initial_level = 3  

t.penup()
t.goto(-initial_distance, 0)
t.pendown()


drawFractalLine(t, initial_distance, 0, initial_level)
t.right(120)
drawFractalLine(t, initial_distance, 0, initial_level)
t.right(120)
drawFractalLine(t, initial_distance, 0, initial_level)

