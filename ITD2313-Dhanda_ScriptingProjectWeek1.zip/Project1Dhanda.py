
name = (input("Enter your name: "))
address = (input("Enter your address: "))
phonenumber = int(input("Enter your phone number: "))
print(name)
print(address)
print(phonenumber)


