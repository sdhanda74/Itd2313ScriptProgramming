from breezypythongui import EasyFrame

class TaxCalculator(EasyFrame):
    def __init__(self):
        EasyFrame.__init__(self, title="Tax Calculator")

        # Add labels and entry fields
        self.addLabel(text="Gross Income:", row=0, column=0, sticky="W")
        self.grossIncomeField = self.addFloatField(value=0.0, row=0, column=1)

        self.addLabel(text="Dependents:", row=1, column=0, sticky="W")
        self.dependentsField = self.addIntegerField(value=0, row=1, column=1)

        # Add Compute button
        self.addButton(text="Compute", row=2, column=1, command=self.computeTax)

        self.addLabel(text="Total Tax:", row=3, column=0, sticky="W")
        self.totalTaxLabel = self.addLabel(text="", row=3, column=1)

    def computeTax(self):
        grossIncome = self.grossIncomeField.getNumber()
        dependents = self.dependentsField.getNumber()

        # Example tax calculation formula
        taxRate = 0.2
        totalTax = grossIncome * taxRate

        self.totalTaxLabel["text"] = f"${totalTax:.2f}"

def main():
    TaxCalculator().mainloop()

if __name__ == "__main__":
    main()

    main()
