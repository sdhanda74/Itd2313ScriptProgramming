
filename = input("Enter the filename: ")


file = open(filename, 'r')
content = file.readlines()
file.close()

numbers = list(map(float, filter(lambda line: line.strip().isdigit(), content)))

average = sum(numbers) / len(numbers) if numbers else 0

print(f"The average of the numbers is: ", average)
