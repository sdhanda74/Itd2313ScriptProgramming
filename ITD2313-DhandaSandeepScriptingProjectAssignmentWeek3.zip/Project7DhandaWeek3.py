import math

year = input("Enter the number of years: ")
minutes = (60 * 24) * 365
Answer = int(year) * minutes

print("The number of minutes in", year, "year(s) is", Answer)


