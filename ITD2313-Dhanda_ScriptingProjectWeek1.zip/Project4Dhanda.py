radius = float(input("Enter the radius: "))
area = 3.14 * radius **2
print("The area of the circle is", area)
