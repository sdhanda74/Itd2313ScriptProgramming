side1 = int(input("Enter the first side of triangle: "))
side2 = int(input("Enter the second side of triangle: "))
side3 = int(input("Enter the third side of triangle: "))

if side1 == side2 and side2 == side3 and side1 == side3:
    print("The triange is an equilateral triangle ")
else:
    print("Sides are not equal, hence not an equilateral triangle ")
    
    
    
    
