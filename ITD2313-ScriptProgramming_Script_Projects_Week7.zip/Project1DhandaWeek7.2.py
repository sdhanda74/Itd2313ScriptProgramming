# print the mean
numbers = [1, 2, 3, 4, 5, 6]
def mean(number):
    sumtotal = sum(numbers)
    numbercount = len(numbers)
    mean2 = sumtotal / numbercount
    return mean2
print(mean(numbers))

    
n_num = [1, 2, 3, 4, 5] 
n = len(n_num) 
n_num.sort() 
 
if n % 2 == 0: 
    median1 = n_num[n//2] 
    median2 = n_num[n//2 - 1] 
    median = (median1 + median2)/2
else: 
    median = n_num[n//2] 
print("Median is: " + str(median))


number_list = [1, 2, 3, 4, 4, 5, 5, 6, 7, 8, 8, 8]
uniq_values = []
mode_values = []
for i in number_list:
    maxValue = max(number_list)
   
print(maxValue)
