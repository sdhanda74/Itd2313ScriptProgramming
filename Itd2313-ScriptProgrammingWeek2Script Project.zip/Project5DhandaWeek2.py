"""calculate an object's momentum using velocity and mass as inputs
"""
mass = float(input("Enter the object's mass: "))
velocity = int(input("Enter the velocity: "))
momentum = mass * velocity
print("The object's momentum is: ", momentum, "kg m/s")
