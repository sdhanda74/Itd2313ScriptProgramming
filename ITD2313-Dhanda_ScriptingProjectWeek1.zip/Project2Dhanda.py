width = float(input("Enter the width: "))
height = float(input("Enter the height: "))
area = width * height
print("The area of the rectangle is", area, "square units.")


